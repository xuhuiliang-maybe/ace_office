# encoding: utf-8
from setuptools import setup

setup(
    name="ace_office",
    version="1.0",
    keywords=("ace_office", "xxx"),
    description="eds sdk",
    long_description="eds sdk for python",
    license="MIT Licence",

    url="http://test.com",
    author="test",
    author_email="test@gmail.com",

    packages=['modules'],
    include_package_data=True,
    platforms="any",
    install_requires=[],

    scripts=[],
    entry_points={}
)
